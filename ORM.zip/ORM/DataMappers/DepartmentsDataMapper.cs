﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;

using ORM.DataAccess;
using ORM.DataModels;

namespace ORM.DataMappers
{
    public class DepartmentsDataMapper : DataAccess<Department>
    {

    }
}
